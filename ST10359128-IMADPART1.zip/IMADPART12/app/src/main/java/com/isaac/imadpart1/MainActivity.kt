package com.isaac.imadpart1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // declaring all variable
        // setting numbers entered to integers

        var edtNum1 = findViewById<EditText>(R.id.edtNum1)
        var edtNum2 = findViewById<EditText>(R.id.edtNum2)
        var btnAdd = findViewById<Button>(R.id.btnAdd)
        var btnSubtract = findViewById<Button>(R.id.btnSubtract)
        var btnMultiply = findViewById<Button>(R.id.btnMultiply)
        var btnDivide = findViewById<Button>(R.id.btnDivide)
        var tvDisplay = findViewById<TextView>(R.id.tvDisplay)

        val res1 = edtNum1.text.toString().toInt()
        val res2 = edtNum2.text.toString().toInt()

        // adding functionality to the "Add" Button
        btnAdd.setOnClickListener {
            val result = res1 + res2
            tvDisplay.text = "$edtNum1 + $edtNum2 = $result"
        }
        // adding functionality to the "Subtract" Button
        btnSubtract.setOnClickListener {
            val result = res1 - res2
            tvDisplay.text = "$edtNum1 - $edtNum2 = $result"
        }
        // adding functionality to the "Multiply" Button
        btnMultiply.setOnClickListener {
            val result = res1 * res2
            tvDisplay.text = "$edtNum1 * $edtNum2 = $result"
        }
        // adding functionality to the "Divide" Button
        btnDivide.setOnClickListener {
            val result = res1 / res2
            tvDisplay.text = "$edtNum1 / $edtNum2 = $result}"
        }

    }
}